package com.javacode.playerservice.playerauction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayerServicePlayerauctionApplicationTests {

	@Test
	void contextLoads() {
	}

}
