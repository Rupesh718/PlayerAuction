package com.javacode.userservice.playeraution.model;

public enum Hobbies {
	Cooking,
	Dancing,
	Drawing,
	Travelling;
}
