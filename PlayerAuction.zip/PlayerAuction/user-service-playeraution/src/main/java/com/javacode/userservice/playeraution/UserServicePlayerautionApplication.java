package com.javacode.userservice.playeraution;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserServicePlayerautionApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserServicePlayerautionApplication.class, args);
	}

}
