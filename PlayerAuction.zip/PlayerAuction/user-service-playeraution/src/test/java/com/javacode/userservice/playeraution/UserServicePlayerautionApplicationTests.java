package com.javacode.userservice.playeraution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServicePlayerautionApplicationTests {

	@Test
	void contextLoads() {
	}

}
