package com.javacode.teamservice.playerauction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamServicePlayerauctionApplicationTests {

	@Test
	void contextLoads() {
	}

}
